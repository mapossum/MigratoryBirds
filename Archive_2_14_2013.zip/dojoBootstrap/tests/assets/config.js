var dojoConfig = {
    async: 1,
    cacheBust: 1,
    parseOnLoad: true,
    tlmSiblingOfDojo: false,
    packages: [
        { name: "dojo", location: "../../../vendor/dojo/dojo" },
        { name: "bootstrap", location: "../../.." },
        { name: "tests", location: "../../../tests" }
    ]
};